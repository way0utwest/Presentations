-- semantickeyphrase
USE UnstructuredData
;
go

-- most common phrases in all documents
SELECT name, document_key, keyphrase, score
 FROM semantickeyphrasetable( AuthorDrafts, *) AS b
   INNER JOIN AuthorDrafts a
     ON a.path_locator = b.document_key
 ORDER BY
    name
  , score DESC
 ;
   
-- row 881


-- Find the Key Phrases in a Document
DECLARE @DocID hierarchyid

SELECT @DocID = path_locator from dbo.AuthorDrafts where name = 'The_Adventures_of_Tom_Sawyer_NT.pdf'

SELECT 
  keyphrase
, score
 FROM SEMANTICKEYPHRASETABLE(AuthorDrafts, *, @DocID)
 ORDER BY 
  score DESC
;
GO
select @@ROWCOUNT as RowsCount
GO





