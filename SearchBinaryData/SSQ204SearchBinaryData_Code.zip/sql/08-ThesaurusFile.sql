-- thesaurus files

-- ts + (three letter language) + .xml
-- tseng.xml

-- edit manually. First time, remove comments


-- load thesaurus File
USE UnstructuredData
;
GO
EXEC sys.sp_fulltext_load_thesaurus_file 1033;
GO

SELECT
 name
 FROM authordrafts
 WHERE FREETEXT(*, 'paint')
 ;

