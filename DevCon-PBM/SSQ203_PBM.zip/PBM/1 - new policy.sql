-- Facets
-- Expand, right click


-- Conditions
-- create a new condition
-- Name: Key Length
-- Target: Asymmetric Key
--  = 256

-- Policy
-- New
-- Name: Check Symmetric Key Length
-- Condition: Key length
-- Target: all databases


-- evalute

-- problems
-- can't change name
-- can't change condition

-- delete, redo
-- evaluate

