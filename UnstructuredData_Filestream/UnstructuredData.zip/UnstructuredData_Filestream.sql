-- Unstructured Data

-- Configuration Manager

-- check server setting

-- check filestream at database level


-- check products:
select 
  Title
, FileName
, FileExtension
, DocumentSummary
, Document
 from Production.Document;
 go


-- look at products with documents.
select 
  Title
, FileName
, FileExtension
, DocumentSummary
, Document
 from Production.Document
 where document is not null
 ;
go

-- Extract documents
-- Explorer  \Users\Steve\Documents\UnstructuredData
-- view .ps1

-- Open Explorer to \Users\Steve\Documents\Docs

-- Run Powershell






-- cleanup
-- delete files in \users\steve\documents\docs






