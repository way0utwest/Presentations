-- create a new database
create database UnstructuredData
go


-- add a filestream FG
ALTER DATABASE [UnstructuredData] ADD FILEGROUP [FS] CONTAINS FILESTREAM 
GO





-- Add a file to the Filestream FG
ALTER DATABASE [UnstructuredData] 
  ADD FILE ( NAME = N'UnstructuredFS', FILENAME = N'c:\fs\UnstructuredFS' ) TO FILEGROUP [FS]
go








-- Enable the database for access, specify the folder for storage. This is 
alter database UnstructuredData
  SET FILESTREAM 
      ( NON_TRANSACTED_ACCESS = FULL, 
	    DIRECTORY_NAME = N'FS' );
go


Use UnstructuredData
go

-- Create a filetable
CREATE TABLE AuthorDrafts AS FileTable
GO



-- check the table.
select *
 from AuthorDrafts;
go




-- check the filetable
SELECT * FROM sys.filetables;
GO

-- check the share
select  FileTableRootPath('dbo.AuthorDrafts');
go





-- copy files





-- check the table.
select *
 from AuthorDrafts;




 -- delete some image files from explorer

select *
 from AuthorDrafts
 where right(name, 3) = 'jpg';


 -- delete files from T-SQL
 delete authordrafts
  where right(name, 3) = 'pdf';

-- check the table.
select *
 from AuthorDrafts;


-- issue checkpoint
checkpoint;


-- check the table.
select *
 from AuthorDrafts;






 -- clean up
 use master;
 go
 drop database UnstructuredData;
