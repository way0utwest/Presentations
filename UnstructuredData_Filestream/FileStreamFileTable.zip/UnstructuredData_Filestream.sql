/*
Filestream Demo

Steve Jones, copyright 2012 

This code is provided as is for demonstration purposes. It may not be suitable for
your environment. Please test this on your own systems. This code may not be republished 
or redistributed by anyone without permission.
You are free to use this code inside of your own organization.
*/

-- Unstructured Data
-- setup
-- Filestream - CD Documents, CD UnstructuredData
-- Explorer - c:\Program Files\Microsoft SQL Server\MSSQL

-- Configuration Manager
-- enable Filestream in Configuration Manager. Make sure the share name is set


-- check server setting
EXEC sp_configure
;
EXEC sp_configure filestream_access_level, 2;
GO
RECONFIGURE;
GO
-- if necessary, enable Filestream in instance properties


-- check filestream at database level
-- look at database properties.



-- check products:
USE AdventureWorks2008
;
GO
select 
  Title
, FileName
, FileExtension
, DocumentSummary
, Document
 from Production.Document;
 go


-- look at products with documents.
select 
  Title
, FileName
, FileExtension
, DocumentSummary
, Document
 from Production.Document
 where document is not null
 ;
go

-- Extract documents
-- Explorer  \Users\Steve\Documents\UnstructuredData
-- view .ps1

-- Open Explorer to \Users\Steve\Documents\Docs

-- Run Powershell



-- load data

-- create a new table
CREATE TABLE FSDemo
(
	id UNIQUEIDENTIFIER ROWGUIDCOL NOT NULL UNIQUE
  , name VARCHAR(20)  
  , jpg varbinary(MAX) FILESTREAM
);
go

INSERT INTO FSDemo(ID, name, jpg) 
Values (NEWID()
      , 'Uma.jpg'
      , (SELECT * FROM OPENROWSET(BULK N'C:\Users\Steve\Documents\SampleData\Uma.jpg', SINGLE_BLOB) AS CategoryImage));
go
SELECT *
 FROM FSDemo
;



-- cleanup
-- delete files in \users\steve\documents\docs
DROP TABLE fsDemo;
go






